import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        TabView {
            FirstScreen()
            SecondScreen()
            ThirdScreen()
            FourthScreen()
        }
        .tabViewStyle(PageTabViewStyle())
        .frame(width: 800, height: 500)
    }
}
let Color1 : Color = Color(red: 214/255, green: 208/255, blue: 208/255)
let Color2 : Color = Color(red: 255/255, green: 255/255, blue: 255/255)
struct FirstScreen: View {
    var body: some View {
        //Color.gray
        HStack {
            VStack (alignment: .center) {
                Text("Once upon a time, there was a man with his son William.They loved to sell products in their family store. Every day they sold a lot of staffs for everyone and helped many poor people to eat and use great products for good prices.")
                    .font(Font.custom("BASKE9", size: 12))
                    .frame(width: 300, height: 150)
                    .padding(50)
                Spacer()
                Image(uiImage: UIImage(named: "2.png")!)
                    .resizable()
                    .frame(width: 250, height: 220)
                    .padding(50)
            }
            
            VStack {
                Image(uiImage: UIImage(named: "1.png")!)
                    .resizable()
                    .frame(width: 227, height: 218, alignment:.topTrailing)
                    .padding(80)
                Spacer()
                Text(" But one day they and humanity had known about a new virus that was supposed to not be dangerous or very infectious. No one was expected to meet it at their house and really don’t trust that it is possible anyway.")
                    .font(.custom("Baskervville", size: 12))
                    .frame(width: 300, height: 150)
                    .padding(50)
            }
        }
        .background(Color1)
    }
}

struct SecondScreen: View {
    var body: some View {
        HStack {
            VStack (alignment: .center) {
                Text("Because of that thinking, humans thought that it was a joke, a worldwide conspiracy, or a very very weak virus. And there were a little count of countries that started do something before the critical moment of the pandemic.")
                    .font(Font.custom("BASKE9", size: 12))
                    .frame(width: 300, height: 150)
                    .padding(50)
                Spacer()
                Image(uiImage: UIImage(named: "4.png")!)
                    .resizable()
                    .frame(width: 250, height: 220)
                    .padding(50)
            }
            
            VStack {
                Image(uiImage: UIImage(named: "3.png")!)
                    .resizable()
                    .frame(width: 227, height: 218, alignment:.topTrailing)
                    .padding(50)
                Spacer()
                Text("  Until finally the government lost control of the situation. Economics of many countries were broken and many of them are suffering for nowadays. Unfortunately, a lot of people are gone and William’s father too. For the boy, it was very hard to cope with the loss. And he was burned by the idea to create an application that can verify if you have some problems with your health.")
                    .font(.custom("Baskervville", size: 12))
                    .frame(width: 300, height: 150)
                    .padding(50)
            }
        }
        .background(Color2)
    }
}


struct ThirdScreen: View {
    var body: some View {
        HStack {
            VStack (alignment: .center) {
                Image(uiImage: UIImage(named: "5.png")!)
                    .resizable()
                    .frame(width: 250, height: 220)
                    .padding(50)
                Spacer()
                Text("When he finished the application there were no ways to test it on the persons with the problem of health and William decided for dangerous step and fall ill for testing his application. And as he supposed, the app worked as needed and he saw the positive result of Covid. He was a hero for all people because it was a revolution in medicine.")
                    .font(Font.custom("BASKE9", size: 12))
                    .frame(width: 300, height: 150)
                    .padding(50)
            }
            
            VStack {
                Text("And ever since then he was working very hard for a long time. Everyone thought that is not his problem and responsibility to create an app like that but William never give up.")
                    .font(.custom("Baskervville", size: 12))
                    .frame(width: 300, height: 150)
                    .padding(50)
                Spacer()
                Image(uiImage: UIImage(named: "6.png")!)
                    .resizable()
                    .frame(width: 227, height: 218, alignment:.topTrailing)
                    .padding(50)
            }
        }
        .background(Color1)
    }
}

struct FourthScreen: View {
    var body: some View {
        VStack {
            Text("After half a year of scientific research, William’s application start works for people throughout the world and help prevent a thousand deaths and keep lifes safe.")
                .font(Font.custom("BASKE9", size: 12))
                .frame(width: 400, height: 100)
                .padding(50)
            
            HStack {
                Image(uiImage: UIImage(named: "8.png")!)
                    .resizable()
                    .frame(width: 207, height: 200)
                Image(uiImage: UIImage(named: "9.png")!)
                    .resizable()
                    .frame(width: 350, height: 195)
                Image(uiImage: UIImage(named: "10.png")!)
                    .resizable()
                    .frame(width: 190, height: 200)
                    .padding()
            }
        }
        .background(Color2)
    }
}

PlaygroundPage.current.setLiveView(ContentView())
